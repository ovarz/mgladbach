<?php
$users = [
  '1' => [
    'pass' => '1',
    'name' => 'Rafael Frans Usthavia',
    'team' => 'U17 Borussia',
    'file' => 'u14-ask17-Rafael_Frans_Usthavia-dec25'
  ],
  'Auzan Alkhawarizmi' => [
    'pass' => 'u8-230119',
    'name' => 'Auzan Alkhawarizmi',
    'phone' => '6285693890908',
    'team' => 'U8 Fohlen',
    'file' => 'u10-u10BOR-Audric_Alvaronizam-dec25'
  ],
];
?>
