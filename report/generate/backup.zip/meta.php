
<head>  
<meta charset="utf-8">
<meta name="robots" content="noindex, follow">				
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="HandheldFriendly" content="true" />
<meta name="apple-touch-fullscreen" content="yes" />
<meta name="description" content="<?php echo $sitename; ?> <?php echo $menu; ?>">
<link rel="preconnect" href="https://mgladbachacademy.id">
<link rel="dns-prefetch" href="https://mgladbachacademy.id">
<link rel="preconnect" href="https://cdnjs.cloudflare.com">
<link rel="dns-prefetch" href="https://cdnjs.cloudflare.com">
<title><?php echo $sitename; ?> <?php echo $menu; ?></title>
<link href="template/img/favicon.ico?<?php echo $anticache; ?>" rel="icon" type="image/ico" />

<link rel="preload" href="template/fonts/N0bU2SZBIuF2PU_0DXR1.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="template/fonts/E218_cfngu7HiRpPX3ZpNE4kY5zKYvWhrw.woff2" as="font" type="font/woff2" crossorigin>

<style><?php require ($_SERVER['BMG'].'template/css/font.css')?></style>
<style><?php require ($_SERVER['BMG'].'report/rancak.css')?></style>

</head>
<body>